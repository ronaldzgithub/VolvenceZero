import spacy
import warnings
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer


_nlp_spacy = None
_nlp_stanza = None
_vader_analyzer = None


def _get_vader_analyzer():
    """Return a process-wide singleton SentimentIntensityAnalyzer.
    Avoids re-instantiating the analyzer (which loads its lexicon)
    on every call to ``compute_valence``.
    """
    global _vader_analyzer
    if _vader_analyzer is None:
        _vader_analyzer = SentimentIntensityAnalyzer()
    return _vader_analyzer


def spacynlp(text):
    """
    Process the text using the spaCy NLP pipeline.
    """
    nlp = get_spacy_nlp()

    return nlp(text)


_wordnet_checked = False


def ensure_wordnet_downloaded():
    """Download the WordNet corpus on first use (no-op afterwards)."""
    global _wordnet_checked
    if _wordnet_checked:
        return
    import nltk
    from nltk.data import find

    try:
        find("corpora/wordnet")
    except LookupError:
        nltk.download("wordnet")
    _wordnet_checked = True


def get_spacy_nlp():
    global _nlp_spacy
    if _nlp_spacy is None:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            _nlp_spacy = spacy.load("en_core_web_trf")
    return _nlp_spacy

# function changed by Navid 6/30
def get_stanza_nlp(use_gpu=False):
    import stanza
    import torch

    global _nlp_stanza
    if _nlp_stanza is None:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            gpu_available = use_gpu and torch.cuda.is_available()
            if use_gpu and not gpu_available:
                print("[GPU] stanza: CUDA not available, falling back to CPU")
            _nlp_stanza = stanza.Pipeline(
                lang="en",
                processors="tokenize,coref",
                verbose=False,
                use_gpu=gpu_available,
            )
    return _nlp_stanza


def compute_valence(text):
    """
    Compute the valence of a given text based on positive and negative words using Vader Sentiment Analysis.
    Args:
        text (str): The text to analyze.

    Returns:
        str: 'positive', 'negative', or 'neutral'
    """
    analyzer = _get_vader_analyzer()

    vs = analyzer.polarity_scores(text)

    if vs["compound"] > 0.05:
        return "positive"
    elif vs["compound"] < -0.05:
        return "negative"
    else:
        return "neutral"
